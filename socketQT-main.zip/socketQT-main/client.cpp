#include "client.h"
#include "QLabel"
#include "QDebug"

 QLabel *lableC;
Client::Client(QObject  *parent):QObject(parent)
{
        socket =new QTcpSocket(this);

        connect(socket,&QTcpSocket::connected,this,&Client::onConnected);
        connect(socket,&QTcpSocket::readyRead,this,&Client::onReadyRead);
}

void Client::connectToServer(QLabel *lbe)
{
     lableC=lbe;
    socket->connectToHost("127.0.0.1",1234);

    if (!socket->waitForConnected(3000)) {
           qDebug() << "Connection failed!";
    }
}

void Client::sendClienttext(QString str)
{
    qDebug()<<str;
    QByteArray ba = str.toLocal8Bit();
      const char *c_str2 = ba.data();
     socket->write(c_str2);
}

void Client::onConnected()
{
    qDebug() << "Connected to server!";
    socket->write("HELLO,SERVER");

}

void Client::onReadyRead()
{
    QByteArray data = socket->readAll();
    lableC->setText(data);
    //qDebug() << "Data received from server:" << data;

}
