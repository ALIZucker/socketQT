#include "server.h"
#include <QDebug>
#include "QLabel"

 QLabel *lable;
Server::Server(QObject *parent):QTcpServer(parent){


}

void Server::startSearver(QLabel *lbe)
{
            lable=lbe;

            if(!this->listen(QHostAddress::Any,1234)){
                qDebug()<<"Server could not start";
            }else {
                qDebug()<<"Server started!";
            }
}

void Server::sendServertext(QString str)
{
        QByteArray ba = str.toLocal8Bit();
          const char *c_str2 = ba.data();
         socket->write(c_str2);
}

void Server::incomingConnection(qintptr socketDescripto)
{
        socket=new QTcpSocket(this);

        if(!socket->setSocketDescriptor(socketDescripto)){
            qDebug()<<"Error socket!";
            return;
        }

        connect(socket,&QTcpSocket::readyRead,this,&Server::onReadyRead);
        connect(socket,&QTcpSocket::disconnected,this,&Server::onDisconnected);

        qDebug()<<"client connect!";

}

void Server::onReadyRead()
{
            QByteArray data=socket->readAll();
              lable->setText(data);


}

void Server::onDisconnected()
{
    qDebug() << "Client disconnected.";
       socket->deleteLater();
}




