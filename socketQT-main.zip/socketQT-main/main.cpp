#include "mainwindow.h"

#include <QApplication>
#include "server.h"
#include "client.h"
#include <QPushButton>
#include "QObject"
#include "QDebug"
#include <QLabel>
#include <QLineEdit>


QLineEdit  *serverEdite;
QLineEdit  *clientEdite;
Server s;
Client c;


void show(){
    s.sendServertext(serverEdite->text());
}
void showC(){
    qDebug()<<clientEdite->text();
c.sendClienttext(clientEdite->text());
}



int main(int argc, char *argv[])
{


    QApplication a(argc, argv);
    QWidget window;
    window.setStyleSheet("QWidget{background-color:#68d484; }");
    window.setGeometry(200,100,550,300);
    QPushButton *botserver=new  QPushButton(&window);
    botserver->setGeometry(80,250,80,25);
    botserver->setText("server");
    botserver->setStyleSheet("QPushButton{background-color:red;color:white}\
                             QPushButton::hover{background-color:black;color:white}");
    QPushButton *botclient=new  QPushButton(&window);
    botclient->setGeometry(400,250,80,25);
    botclient->setText("client");
    botclient->setStyleSheet("QPushButton{background-color:red;color:white}\
                             QPushButton::hover{background-color:black;color:white}");

     serverEdite=new QLineEdit(&window);
    serverEdite->setGeometry(60,180,130,45);
    serverEdite->setStyleSheet("QLineEdit{background-color:white;color:black; font-size:14pt;}");

    clientEdite=new QLineEdit(&window);
    clientEdite->setGeometry(380,180,130,45);
    clientEdite->setStyleSheet("QLineEdit{background-color:white;color:black; font-size:14pt;}");

    QLabel *lableserver=new QLabel(&window);
    lableserver->setGeometry(50,70,160,45);
    lableserver->setText(" ");
    lableserver->setStyleSheet("QLabel{background-color:white;color:black; font-size:12pt;}");
   // lableserver->setStyleSheet("QLabel{font-size: 18pt;");

    QLabel *lableclient=new QLabel(&window);
    lableclient->setGeometry(360,70,160,45);
    lableclient->setText(" ");
    lableclient->setStyleSheet("QLabel{background-color:white;color:black; font-size:12pt;}");
  //  lableclient->setStyleSheet('QLabel { font-size: 14pt;}');

    QObject::connect(botserver,&QPushButton::clicked,&show);
    QObject::connect(botclient,&QPushButton::clicked,&showC);

    window.show();


    s.startSearver(lableserver);
  //  s.sendServertext();


    c.connectToServer(lableclient);
    return a.exec();
}


